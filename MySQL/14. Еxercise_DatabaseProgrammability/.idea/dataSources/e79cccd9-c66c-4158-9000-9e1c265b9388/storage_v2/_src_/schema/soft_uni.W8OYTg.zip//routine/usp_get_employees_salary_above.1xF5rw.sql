create
    definer = root@localhost procedure usp_get_employees_salary_above(IN salary_number decimal(19, 4))
BEGIN
    SELECT employees.first_name, employees.last_name
    FROM employees

    WHERE salary >= salary_number
    ORDER BY first_name ASC, last_name ASC, employee_id ASC;
END;

