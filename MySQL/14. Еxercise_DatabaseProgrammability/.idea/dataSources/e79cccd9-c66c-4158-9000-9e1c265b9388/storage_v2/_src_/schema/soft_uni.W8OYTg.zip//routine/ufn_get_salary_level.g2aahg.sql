create
    definer = root@localhost function ufn_get_salary_level(salaryNumber decimal(19, 4)) returns varchar(7) deterministic
    RETURN (
        CASE
            WHEN salaryNumber < 30000 THEN 'Low'
            WHEN salaryNumber <= 50000 THEN 'Average'
            ELSE 'High'
            END
        );

