create
    definer = root@localhost procedure usp_get_employees_by_salary_level(IN level_salary varchar(7))
BEGIN
    SELECT employees.first_name, employees.last_name
    FROM employees
    WHERE (salary < 30000 AND level_salary = 'Low')
       OR (salary >= 30000 AND salary <= 50000 AND level_salary = 'Average')
       OR (salary > 50000 AND level_salary = 'High')
    ORDER BY first_name DESC, last_name DESC;
END;

