create
    definer = root@localhost procedure usp_get_towns_starting_with(IN string varchar(50))
BEGIN
    SELECT towns.name
    FROM towns
    WHERE name LIKE CONCAT(string, '%')
    ORDER BY name ASC;
END;

