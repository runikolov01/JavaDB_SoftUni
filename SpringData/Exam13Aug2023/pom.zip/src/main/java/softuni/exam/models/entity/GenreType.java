package softuni.exam.models.entity;

public enum GenreType {
    CLASSIC_LITERATURE, SCIENCE_FICTION, FANTASY
}
