package softuni.exam.service.impl;

import softuni.exam.service.MechanicsService;

import java.io.IOException;
// TODO: Implement all methods
public class MechanicsServiceImpl implements MechanicsService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readMechanicsFromFile() throws IOException {
        return null;
    }

    @Override
    public String importMechanics() throws IOException {
        return null;
    }
}
