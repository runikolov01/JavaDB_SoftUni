package softuni.exam.service.impl;

import softuni.exam.service.PartsService;

import java.io.IOException;
// TODO: Implement all methods
public class PartsServiceImpl implements PartsService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readPartsFileContent() throws IOException {
        return null;
    }

    @Override
    public String importParts() throws IOException {
        return null;
    }
}
