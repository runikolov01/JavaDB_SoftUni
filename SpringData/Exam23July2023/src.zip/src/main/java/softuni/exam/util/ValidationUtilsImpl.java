package softuni.exam.util;

public class ValidationUtilsImpl {
}
